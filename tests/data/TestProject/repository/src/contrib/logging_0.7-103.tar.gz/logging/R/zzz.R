
## create the logging environment
logging.options <- new.env()

## initialize the module
logReset()
