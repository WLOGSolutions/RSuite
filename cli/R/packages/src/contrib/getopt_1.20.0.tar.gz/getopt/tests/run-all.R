library("testthat")
library("getopt")

test_package("getopt")
