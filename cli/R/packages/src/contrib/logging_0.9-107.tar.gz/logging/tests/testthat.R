library(testthat)
library(logging)

test_check("logging")
